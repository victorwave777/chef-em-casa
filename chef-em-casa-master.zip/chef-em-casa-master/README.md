# Chefe em Casa

Projeto desenvolvido no curso do Senac 2023.2

# Tecnologias
- Bootstrap
- PHP
- MySQL